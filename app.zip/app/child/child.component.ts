import { Component,Output, OnInit } from '@angular/core';
import {  EventEmitter } from '@angular/core';
@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Output() customerEvent= new EventEmitter();
  
   ob={
     name:"riya",
     address:"chennai",
     id:89,
     age:23
   }
  constructor() { }

  ngOnInit() {
  }
  callParentGreet(){
    this.customerEvent.emit(this.ob); 
  }
}
