import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo parent';

  greet(ob:any){
alert(`name is ${ob.name},id is ${ob.id} age is ${ob.age},address is ${ob.address}`)

}
}