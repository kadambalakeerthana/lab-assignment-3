import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Mod2Module } from './mod2/mod2.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
  
})
export class Mod1Module { }
