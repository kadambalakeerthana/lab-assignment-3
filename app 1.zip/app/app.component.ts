import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  companyData=[
    {"id":342, "name":"HCL","address":"channai"},
    {"id":372, "name":"HCL","address":"Noida"},
    {"id":382, "name":"HCL","address":"Bangalore"}
  ]
  data(name:string){
    alert(`data is ${name}`)
  }
  title = 'demo1';
}
